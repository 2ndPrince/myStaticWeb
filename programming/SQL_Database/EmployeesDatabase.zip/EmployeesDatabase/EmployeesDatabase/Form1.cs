﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeesDatabase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DatabaseConnection objConnect;
        string conString;

        DataSet ds;
        DataRow dRow;

        int MaxRows;
        int inc = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            btnAddNew.Enabled = true;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;

            try
            {
                objConnect = new DatabaseConnection();
                conString = Properties.Settings.Default.EmployeesConnectionString;

                objConnect.connection_string = conString;
                objConnect.Sql = Properties.Settings.Default.SQL;

                ds = objConnect.GetConnection; // calls MyDataset()
                MaxRows = ds.Tables[0].Rows.Count; // Number of Rows in a table[0]

                NavigateRecords();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void NavigateRecords()
        {
            if(inc<0 || inc > MaxRows-1)
            {
                MessageBox.Show("No More Rows");
            }
            else
            {
                dRow = ds.Tables[0].Rows[inc];
                txtFirstName.Text = dRow.ItemArray.GetValue(1).ToString();
                txtSurName.Text = dRow.ItemArray.GetValue(2).ToString();
                txtJobTitle.Text = dRow.ItemArray.GetValue(3).ToString();
                txtDepartment.Text = dRow.ItemArray.GetValue(4).ToString();
            }                            
        }

        private void btnNext_Click(object sender, EventArgs e)
        {

            if (inc < MaxRows - 1)
            {
                inc++;
                NavigateRecords();
            }
            else
            {
                MessageBox.Show("No More Rows");
            }
            
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (inc > 0)
            {
                inc--;
                NavigateRecords();
            }
            else
            {
                MessageBox.Show("No Previous Record");                    
            }
            
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            inc = 0;
            NavigateRecords();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            inc = MaxRows - 1;
            NavigateRecords();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            txtDepartment.Clear();
            txtFirstName.Clear();
            txtJobTitle.Clear();
            txtSurName.Clear();

            btnAddNew.Enabled = false;
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            NavigateRecords();

            btnAddNew.Enabled = true;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataRow row = ds.Tables[0].NewRow();
            row[1] = txtFirstName.Text;
            row[2] = txtSurName.Text;
            row[3] = txtJobTitle.Text;
            row[4] = txtDepartment.Text;

            ds.Tables[0].Rows.Add(row); // Add a record to the dataset

            try
            { // Add a record also to the database
                objConnect.UpdateDatabase(ds);
                MaxRows++;
                inc = MaxRows - 1;

                MessageBox.Show("Database Updated");
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }

            btnAddNew.Enabled = false;
            btnSave.Enabled = false;
            btnCancel.Enabled = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DataRow row = ds.Tables[0].Rows[inc];

            row[1] = txtFirstName.Text;
            row[2] = txtSurName.Text;
            row[3] = txtJobTitle.Text;
            row[4] = txtDepartment.Text;

            try
            {
                objConnect.UpdateDatabase(ds);
                MessageBox.Show("Record Updated");
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }

        }
        
        private void btnDelete_Click(object sender, EventArgs e)
        {            
            try
            {
                ds.Tables[0].Rows[inc].Delete();

                objConnect.UpdateDatabase(ds);

                MaxRows -= 1;
                inc--;

                NavigateRecords();
                MessageBox.Show("Record Deleted");
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }
    }
}
