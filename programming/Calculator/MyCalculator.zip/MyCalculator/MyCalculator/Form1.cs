﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyCalculator
{
    public partial class Form1 : Form
    {
        double value = 0;
        String operation = "";
        bool operation_pressed = false;

        public Form1()
        {
            InitializeComponent();
        }         

        private void button_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0")) // Prevents first digit 0 numbers such as 09 or 0053.
            {
                textBox1.Clear();
            }                

            Button b = (Button)sender;   
            if(b.Text == ".")
            {
                if(!textBox1.Text.Contains("."))
                    textBox1.Text = textBox1.Text + b.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + b.Text;
            }      
            
        }

        private void button_Clear(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button_CE(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void button_Operator(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            

            if(textBox1.Text != "") // Preventing clicking operator twice cracks the program bc text is cleared and its asking for value.
            {
                value = Double.Parse(textBox1.Text);
            }


            operation = b.Text;
            textBox1.Clear();
            operation_pressed = true;
            temp.Text = value.ToString() + " " + operation;
        }

        private void button_Equal(object sender, EventArgs e)
        {
            temp.Clear();
            switch (operation)
            {
                case "+":
                    textBox1.Text = (value + Double.Parse(textBox1.Text)).ToString();
                    break;

                case "-":
                    textBox1.Text = (value - Double.Parse(textBox1.Text)).ToString();
                    break;

                case "*":
                    textBox1.Text = (value * Double.Parse(textBox1.Text)).ToString();
                    break;

                case "/":
                    textBox1.Text = (value / Double.Parse(textBox1.Text)).ToString();
                    break;

                default:
                    break;

            } // end of switch           
        }        

    }
}
