﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = int.Parse(textBox1.Text) + int.Parse(textBox2.Text);
            richTextBox1.Text = richTextBox1.Text + "sum: " + sum.ToString() + Environment.NewLine;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int mul = int.Parse(textBox1.Text) * int.Parse(textBox2.Text);
            richTextBox1.Text = richTextBox1.Text + "mul: " + mul.ToString() + Environment.NewLine;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int sub = int.Parse(textBox1.Text) - int.Parse(textBox2.Text);
            richTextBox1.Text = richTextBox1.Text + "sub: " + sub.ToString() + Environment.NewLine;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int div = int.Parse(textBox1.Text) / int.Parse(textBox2.Text);
            richTextBox1.Text = richTextBox1.Text + "div: " + div.ToString() + Environment.NewLine;
        }

        private void textBox1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1ToolStripMenuItem.Checked = !textBox1ToolStripMenuItem.Checked; // toggling
            if (textBox1ToolStripMenuItem.Checked)
            {
                textBox1.Visible = true;
            }
            else
            {
                textBox1.Visible = false;
            }
            
        }

        private void textBox2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox2ToolStripMenuItem.Checked = !textBox2ToolStripMenuItem.Checked;
            if (textBox2ToolStripMenuItem.Checked)
            {
                textBox2.Visible = true;
            }
            else
            {
                textBox2.Visible = false;
            }
        }

        private void richTextBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxToolStripMenuItem.Checked = !richTextBoxToolStripMenuItem.Checked;
            if (richTextBoxToolStripMenuItem.Checked)
            {
                richTextBox1.Visible = true;
            }
            else
            {
                richTextBox1.Visible = false;
            }
        }

        private void loadImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFD.Title = "Insert an Image";
            openFD.FileName = ""; // Clears default filename text inserted (openFileDialog1)
            openFD.Filter = "JPEG|*.jpg|PNG|*.png|All Files|*.*";

            openFD.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal); // Document folder of any computer.
            //openFD.ShowDialog(); // Fileopen dialog, nothing happens without this.

            if (openFD.ShowDialog() != DialogResult.Cancel) // Handles dialog cancel
            {
                string Chosen_File = openFD.FileName;
                pictureBox1.Image = Image.FromFile(Chosen_File); // Using FromFile Method
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string places = "";
            string best_place = "";
            if (checkBox1.Checked)
            {
                places += checkBox1.Text + Environment.NewLine;
            }

            if (checkBox2.Checked)
            {
                places += checkBox2.Text + Environment.NewLine;
            }

            if (checkBox3.Checked)
            {
                places += checkBox3.Text + Environment.NewLine;
            }

            if (radioButton1.Checked)
            {
                best_place = radioButton1.Text;
            }
            else if (radioButton2.Checked)
            {
                best_place = radioButton2.Text;
            }
            else if (radioButton3.Checked)
            {
                best_place = radioButton3.Text;
            }

            MessageBox.Show("Liked places are: " + places + Environment.NewLine 
                + "Favorite place is: " + best_place
                , "Where do you want to go?"
                , MessageBoxButtons.OKCancel);
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To be implemented soon");
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To be implemented soon");
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
